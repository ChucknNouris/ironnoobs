export function calculateHighAlch(itemValue: number): number {
  return Math.floor(itemValue * 0.6)
}
